# DevFlowKit

A lightweight, modular command-line toolkit for inspecting software projects and generating a quick project-health report.

## Features
- Summarizes files by extension
- Counts lines in common text/code files
- Finds `TODO`, `FIXME`, and `XXX` markers
- Checks for a README, license, and tests directory
- Exports a JSON report
- Uses Python's standard library only

## Requirements
Python 3.10 or newer.

## Quick start
From the repository root:

```bash
python -m devflowkit --help
python -m devflowkit scan .
python -m devflowkit scan . --json report.json
```

## Development
Run tests with:

```bash
python -m unittest discover -s tests -v
```

## Roadmap
- Configurable ignore patterns
- Optional Git metadata checks
- HTML report output
- Plugin hooks for custom analyzers

## Status
Early-stage starter project. Its report is not a security audit or a substitute for code review.
