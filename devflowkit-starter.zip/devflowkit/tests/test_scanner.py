import tempfile
import unittest
from pathlib import Path
from devflowkit.scanner import scan_project, format_report

class ScannerTests(unittest.TestCase):
    def test_scan_counts_files_and_markers(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "README.md").write_text("# Demo\nTODO: improve\n", encoding="utf-8")
            (root / "main.py").write_text("print('hello')\n# FIXME later\n", encoding="utf-8")
            (root / "tests").mkdir()
            report = scan_project(root)
            self.assertEqual(report["files_scanned"], 2)
            self.assertEqual(report["markers"]["TODO"], 1)
            self.assertEqual(report["markers"]["FIXME"], 1)
            self.assertTrue(report["essentials"]["README.md"])
            self.assertTrue(report["essentials"]["tests/"])
            self.assertIn("DevFlowKit project report", format_report(report))

    def test_skips_git_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / ".git").mkdir()
            (root / ".git" / "config").write_text("ignored", encoding="utf-8")
            (root / "app.py").write_text("pass\n", encoding="utf-8")
            self.assertEqual(scan_project(root)["files_scanned"], 1)

if __name__ == "__main__":
    unittest.main()
