from collections import Counter
from pathlib import Path
from typing import Any

TEXT_SUFFIXES = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".html", ".css", ".scss",
    ".json", ".yml", ".yaml", ".toml", ".ini", ".md", ".txt", ".sh",
    ".sql", ".java", ".kt", ".go", ".rs", ".c", ".h", ".cpp", ".xml"
}
SKIP_DIRS = {".git", ".venv", "venv", "__pycache__", "node_modules", ".mypy_cache"}
MARKERS = ("TODO", "FIXME", "XXX")

def scan_project(root: Path) -> dict[str, Any]:
    # Scan a project folder and return a JSON-serializable summary.
    root = root.resolve()
    files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative_parts = path.relative_to(root).parts
        if any(part in SKIP_DIRS for part in relative_parts):
            continue
        files.append(path)

    extensions = Counter(path.suffix.lower() or "[no extension]" for path in files)
    marker_counts = Counter()
    total_lines = 0

    for path in files:
        if path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        total_lines += len(content.splitlines())
        for marker in MARKERS:
            marker_counts[marker] += content.count(marker)

    essentials = {
        "README.md": (root / "README.md").is_file(),
        "LICENSE": any((root / name).is_file() for name in ("LICENSE", "LICENSE.md", "LICENSE.txt")),
        "tests/": (root / "tests").is_dir(),
    }

    return {
        "root": str(root),
        "files_scanned": len(files),
        "extensions": dict(sorted(extensions.items())),
        "total_text_lines": total_lines,
        "markers": {marker: marker_counts[marker] for marker in MARKERS},
        "essentials": essentials,
    }

def format_report(report: dict[str, Any]) -> str:
    lines = [
        "DevFlowKit project report",
        f"Root: {report['root']}",
        f"Files scanned: {report['files_scanned']}",
        f"Text lines counted: {report['total_text_lines']}",
        "",
        "File types:",
    ]
    if report["extensions"]:
        lines.extend(f"  {ext}: {count}" for ext, count in report["extensions"].items())
    else:
        lines.append("  No files found")
    lines.extend(["", "Project essentials:"])
    lines.extend(
        f"  {name}: {'found' if exists else 'missing'}"
        for name, exists in report["essentials"].items()
    )
    lines.extend(["", "Markers:"])
    lines.extend(f"  {marker}: {count}" for marker, count in report["markers"].items())
    return "\n".join(lines)
