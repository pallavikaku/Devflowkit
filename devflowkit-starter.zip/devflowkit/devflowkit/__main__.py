import argparse
import json
from pathlib import Path
from .scanner import scan_project, format_report

def main() -> int:
    parser = argparse.ArgumentParser(
        prog="devflowkit",
        description="Generate a lightweight report about a software project."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    scan_parser = subparsers.add_parser("scan", help="Scan a project directory")
    scan_parser.add_argument("path", nargs="?", default=".", help="Directory to scan")
    scan_parser.add_argument("--json", dest="json_path", help="Write a JSON report to this file")
    args = parser.parse_args()

    root = Path(args.path).expanduser().resolve()
    if not root.is_dir():
        parser.error(f"not a directory: {root}")

    report = scan_project(root)
    print(format_report(report))
    if args.json_path:
        output_path = Path(args.json_path).expanduser()
        output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nJSON report written to: {output_path.resolve()}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
